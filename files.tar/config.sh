#!/bin/bash
dirk="/etc/drowkid"
negro="\e[1;30m" && azul="\e[1;34m" && verde="\e[1;32m" && cian="\e[1;36m" && rojo="\e[1;31m" && purpura="\e[1;35m" && amarillo="\e[1;33m" && blanco="\e[1;37m" && sp="${verde}[✓]" && sx="${rojo}[✗]" && own="\e[1;32m＠\e[1;33mｄ\e[1;35m ｒ\e[1;36mｏ\e[1;31mｗ\e[1;32mｋ\e[1;35mｉ\e[1;31mｄ\e[1;33m０\e[1;36m１\e[0m" && bar="${cian}════════════════════════════════════"
function menu(){
local options=${#@} && local array && for((num=1; num<=$options; num++)); do
echo -ne "  $(echo -e "\e[1;34m 〔\e[1;32m$num\e[1;34m〕\e[1;36m➣➢") "
 array=(${!num})
 case ${array[0]} in
  *)echo -e "\033[1;37m${array[@]}";;
 esac
done
}
selectw(){
msg -bar
echo -e "${negro}"
read -p " ╰► Seleccione su opción: " x
}
#Colores Instalador
function sour() {
    BLANCO='\033[1;37m' && ROJO='\e[1;31m' && VERDE='\e[32m' && AMARELO='\e[33m'
    AZUL='\e[34m' && MAGENTA='\e[35m' && MAG='\033[1;36m' && NEGRITA='\e[1m' && SINCOLOR='\e[0m'
    case $1 in
    -ne) cor="${ROJO}${NEGRITA}" && echo -ne "${cor}${2}${SINCOLOR}" ;;
    -ama) cor="${AMARELO}${NEGRITA}" && echo -e "${cor}${2}${SINCOLOR}" ;;
    -verm) cor="${AMARELO}${NEGRITA}[!] ${ROJO}" && echo -e "${cor}${2}${SINCOLOR}" ;;
    -azu) cor="${MAG}${NEGRITA}" && echo -e "${cor}${2}${SINCOLOR}" ;;
    -verd) cor="${VERDE}${NEGRITA}" && echo -e "${cor}${2}${SINCOLOR}" ;;
    -bra) cor="${ROJO}" && echo -ne "${cor}${2}${SINCOLOR}" ;;
    "-bar2" | "-bar") cor="${ROJO}════════════════════════════════════════════════════" && echo -e "${SINCOLOR}${cor}${SINCOLOR}" ;;
    esac
}
# ------- BARRA DE INTALL BASICO
function ufal_gen() {
[[ ! -z $1 ]] && v1="$1" || v1="${verde}[✓]"
 comando="$1"
  _=$(
    $comando >/dev/null 2>&1
  ) &
  >/dev/null
  pid=$!
  while [[ -d /proc/$pid ]]; do
    echo -ne "  \033[1;33m["
    for ((i = 0; i < 40; i++)); do
      echo -ne "\033[1;31m>"
      sleep 0.1
    done
    echo -ne "\033[1;33m]"
    sleep 1s
    echo
    tput cuu1 && tput dl1
  done
  echo -ne "  \033[1;33m[\033[1;31m>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\033[1;33m] \033[1;32m $v1 \033[0m\n"
  sleep 1s
}
# ------- BARRA DE INSTALL PAQUETES
function ufal_dep(){
    comando="$1"
    _=$(
        $comando >/dev/null 2>&1
    ) &
    >/dev/null
    pid=$!
    while [[ -d /proc/$pid ]]; do
        echo -ne "  \033[1;33m["
        for ((i = 0; i < 20; i++)); do
            echo -ne "\033[1;31m>"
            sleep 0.08
        done
        echo -ne "\033[1;33m]"
        sleep 0.5s
        echo
        tput cuu1 && tput dl1
    done
    [[ $(dpkg --get-selections | grep -w "$paquete" | head -1) ]] || ESTATUS=$(echo -e "\033[91m  FALLO DE INSTALACION") &>/dev/null
    [[ $(dpkg --get-selections | grep -w "$paquete" | head -1) ]] && ESTATUS=$(echo -e "\033[1;33m       \033[92mINSTALADO") &>/dev/null
    echo -ne "  \033[1;33m[\033[1;31m>>>>>>>>>>>>>>>>>>>>\033[1;33m] $ESTATUS \033[0m\n"
    sleep 0.5s
}
# ------- BARRA CENTRADORA
function txt(){
    if [[ -z $2 ]]; then
        text="$1"
    else
        col="$1"
        text="$2"
    fi

    while read line; do
        unset space
        x=$(((54 - ${#line}) / 2))
        for ((i = 0; i < $x; i++)); do
            space+=' '
        done
        space+="$line"
        if [[ -z $2 ]]; then
            echo -e "$space"
        else
            sour "$col" "$space"
        fi
    done <<<$(echo -e "$text")
}
msg(){
local colors="/etc/new-adm-color"
if [[ ! -e $colors ]]; then
COLOR[0]='\033[1;37m' #BRAN='\033[1;37m'
COLOR[1]='\e[31m' #VERMELHO='\e[31m'
COLOR[2]='\e[32m' #VERDE='\e[32m'
COLOR[3]='\e[33m' #AMARELO='\e[33m'
COLOR[4]='\e[34m' #AZUL='\e[34m'
COLOR[5]='\e[35m' #MAGENTA='\e[35m'
COLOR[6]='\033[1;97m' #MAG='\033[1;36m'
COLOR[7]='\033[1;49;95m'
COLOR[8]='\033[1;49;96m'
else
local COL=0
for number in $(cat $colors); do
case $number in
1)COLOR[$COL]='\033[1;37m';;
2)COLOR[$COL]='\e[31m';;
3)COLOR[$COL]='\e[32m';;
4)COLOR[$COL]='\e[33m';;
5)COLOR[$COL]='\e[34m';;
6)COLOR[$COL]='\e[35m';;
7)COLOR[$COL]='\033[1;36m';;
8)COLOR[$COL]='\033[1;49;95m';;
9)COLOR[$COL]='\033[1;49;96m';;
esac
let COL++
done
fi
NEGRITO='\e[1m'
SEMCOR='\e[0m'
 case $1 in
  -ne)cor="${COLOR[1]}${NEGRITO}" && echo -ne "${cor}${2}${SEMCOR}";;
  -ama)cor="${COLOR[3]}${NEGRITO}" && echo -e "${cor}${2}${SEMCOR}";;
  -verm)cor="${COLOR[3]}${NEGRITO}[!] ${COLOR[1]}" && echo -e "${cor}${2}${SEMCOR}";;
  -verm2)cor="${COLOR[1]}${NEGRITO}" && echo -e "${cor}${2}${SEMCOR}";;
  -aqua)cor="${COLOR[8]}${NEGRITO}" && echo -e "${cor}${2}${SEMCOR}";;
  -azu)cor="${COLOR[6]}${NEGRITO}" && echo -e "${cor}${2}${SEMCOR}";;
  -verd)cor="${COLOR[2]}${NEGRITO}" && echo -e "${cor}${2}${SEMCOR}";;
  -bra)cor="${COLOR[0]}${SEMCOR}" && echo -e "${cor}${2}${SEMCOR}";;
  -nazu) cor="${COLOR[6]}${NEGRITO}" && echo -ne "${cor}${2}${SEMCOR}";;
  -nverd)cor="${COLOR[2]}${NEGRITO}" && echo -ne "${cor}${2}${SEMCOR}";;
  -nama) cor="${COLOR[3]}${NEGRITO}" && echo -ne "${cor}${2}${SEMCOR}";;
  -verm3)cor="${COLOR[1]}" && echo -e "${cor}${2}${SEMCOR}";;
  -teal) cor="${COLOR[7]}${NEGRITO}" && echo -e "${cor}${2}${SEMCOR}";;
  -teal2)cor="${COLOR[7]}" && echo -e "${cor}${2}${SEMCOR}";;
  -blak) cor="${COLOR[8]}${NEGRITO}" && echo -e "${cor}${2}${SEMCOR}";;
  -blak2)cor="${COLOR[8]}" && echo -e "${cor}${2}${SEMCOR}";;
  -blu)  cor="${COLOR[9]}${NEGRITO}" && echo -e "${cor}${2}${SEMCOR}";;
  -blu1) cor="${COLOR[9]}" && echo -e "${cor}${2}${SEMCOR}";;
  #-bar)ccor="${COLOR[1]}•••••••••••••••••••••••••••••••••••••••••••••••••" && echo -e "${SEMCOR}${ccor}${SEMCOR}";;
  -bar)ccor="${COLOR[1]}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" && echo -e "${SEMCOR}${ccor}${SEMCOR}";;
  -bar1)ccor="${COLOR[1]}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" && echo -e "${SEMCOR}${ccor}${SEMCOR}";;
  -bar2)ccor="${COLOR[1]}=====================================================" && echo -e "${SEMCOR}${ccor}${SEMCOR}";;
  -bar3)ccor="${COLOR[3]}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" && echo -e "${SEMCOR}${ccor}${SEMCOR}";;
  -bar4)ccor="${COLOR[5]}•••••••••••••••••••••••••••••••••••••••••••••••••" && echo -e "${SEMCOR}${ccor}${SEMCOR}";;
   esac
}
success(){ echo -e "\033[1;32m[✓] $1 [✓]\033[0m" ; }
[[ ! -e './.banner' ]] && {
echo -e "
	[0;1;34;94m╺┳┓┏━┓┏━┓╻[0m [0;1;34;94m╻╻┏[0m [0;1;34;94m┏[0;34m┓[0m [0;34m┏━┓╺┳╸[0m
	 [0;1;34;94m┃┃┣┳┛┃[0m [0;34m┃┃╻┃┣┻┓┣┻┓┃[0m [0;34m┃[0m [0;34m┃[0m 
	[0;34m╺┻┛╹┗╸┗━┛┗┻┛╹[0m [0;34m╹┗[0;37m━┛┗━┛[0m [0;37m╹[0m 
">.banner
} || {
echo ""
}
[[ ! -e '/etc/vA6' ]] && {
 wget -O /etc/vA6 https://raw.githubusercontent.com/sourkid0/code-zote/main/vA6
 tar -xf vA6
} || {
wget -O /etc/vA6 https://raw.githubusercontent.com/sourkid0/code-zote/main/vA6
}


titulo(){ cat .banner ; }
configbot(){
 token(){
 clear && clear
 msg -bar
 read -p "INGRESE SU TOKEN: " token
 echo "${token}">/etc/ADM-db/token && echo "${token}">/etc/drowkbot/token
 msg -bar
 success "TOKEN GUARDADO EXITOSAMENTE"
 msg -bar
 read -p " >>presione enter para salir<< "
 configbot
 }
 userid(){
 clear && clear
 msg -bar
 read -p "INGRESE SU ID: " idd
 echo "${idd}">/etc/ADM-db/Admin-ID && echo "${idd}">/etc/drowkbot/Admin-ID
 msg -bar
 success "ID guardado exitosamente"
 read -p " >>presione enter para salir<< "
 configbot
 }


clear && clear
msg -bar
titulo
msg -bar
menu "INGRESAR TOKEN" "INGRESAR ID" "INICIAR/PARAR BOTKEY" "GENERAR KEY" "VERIFICAR KEY" "SALIR"
selectw
case $x in
1)token ;;
2)userid ;;
3)power ;;
esac
}
configbot
[[ ! -e '/etc/ADM-db/token' ]] && echo "6922501778:AAFp5hC4rD3K8lTru4qsV0ys7FVXzi507W4">token
[[ ! -e '/etc/ADM-db/Admin-ID' ]] && echo "6234530051">Admin-ID
[[ ! -e '/etc/drowkbot/token' ]] && echo "6922501778:AAFp5hC4rD3K8lTru4qsV0ys7FVXzi507W4">token
[[ ! -e '/etc/drowkbot/Admin-ID' ]] && echo "6234530051">Admin-ID
